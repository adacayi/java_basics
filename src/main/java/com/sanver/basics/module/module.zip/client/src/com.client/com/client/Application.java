package com.client;
import com.greeter.Greeter;
import java.util.Arrays;
import java.util.ServiceLoader;
import java.util.stream.Collectors;

public class Application{

	public static void main(String... args){
		var name = args.length == 0 ? "Anonymous" : Arrays.stream(args).collect(Collectors.joining(", "));
		
		var loader = ServiceLoader.load(Greeter.class);
		System.out.println("Loaded service count: " + loader.stream().count());
		
		for(var service : loader){
			System.out.printf("Greeter %s. Message: %s%n", service.getClass().getName(), service.greet(name));
		}
	}
}