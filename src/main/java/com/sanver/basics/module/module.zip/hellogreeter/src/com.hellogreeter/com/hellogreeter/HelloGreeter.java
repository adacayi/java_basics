package com.hellogreeter;
import com.greeter.Greeter;

public class HelloGreeter implements Greeter {
	public String greet(String name){
		return "Hello " + name;
	}
}