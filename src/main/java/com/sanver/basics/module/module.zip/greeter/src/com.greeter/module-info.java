module com.greeter {
	exports com.greeter to com.client, com.hellogreeter, com.higreeter;
}