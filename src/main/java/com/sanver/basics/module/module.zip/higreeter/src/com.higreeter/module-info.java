module com.higreeter{
	requires com.greeter;
	provides com.greeter.Greeter with com.higreeter.HiGreeter;
}