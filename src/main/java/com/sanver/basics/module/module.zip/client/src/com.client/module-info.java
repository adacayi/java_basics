module com.client {
	requires com.greeter;
	uses com.greeter.Greeter;
}