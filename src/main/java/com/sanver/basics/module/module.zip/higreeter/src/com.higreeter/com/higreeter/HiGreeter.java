package com.higreeter;
import com.greeter.Greeter;

public class HiGreeter implements Greeter {
	public String greet(String name){
		return "Hi " + name;
	}
}