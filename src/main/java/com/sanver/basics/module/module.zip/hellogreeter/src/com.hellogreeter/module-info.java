module com.hellogreeter {
	requires com.greeter;
	provides com.greeter.Greeter with com.hellogreeter.HelloGreeter;
}