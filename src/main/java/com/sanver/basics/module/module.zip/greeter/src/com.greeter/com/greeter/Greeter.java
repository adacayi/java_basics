package com.greeter;

public interface Greeter {
	String greet(String name);
}